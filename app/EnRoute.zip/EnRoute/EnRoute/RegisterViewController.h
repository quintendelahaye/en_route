//
//  RegisterViewController.h
//  EnRoute
//
//  Created by Quinten Delahaye on 01/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegisterView.h"
#import <AFNetworking.h>
#import "TitleView.h"
#import <SBJson/SBJson4.h>

@interface RegisterViewController : UIViewController

@property (strong,nonatomic)RegisterView *view;

@end
