//
//  LogoView.h
//  EnRoute
//
//  Created by Quinten Delahaye on 05/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogoView : UIView

@property (strong,nonatomic)UIImageView *background;
@property (strong,nonatomic)UIImageView *logo;

@end
