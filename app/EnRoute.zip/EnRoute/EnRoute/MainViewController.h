//
//  MainViewController.h
//  EnRoute
//
//  Created by Quinten Delahaye on 01/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Mainview.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"

@interface MainViewController : UIViewController

@property (strong,nonatomic)Mainview *view;

@end
