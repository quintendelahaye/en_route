//
//  UnlockedView.m
//  EnRoute
//
//  Created by Thomas Verleye on 9/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import "UnlockedView.h"

@implementation UnlockedView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
