//
//  MenuViewController.h
//  EnRoute
//
//  Created by Thomas Verleye on 10/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuView.h"
#import "TitleView.h"

@interface MenuViewController : UIViewController

@property (strong,nonatomic)MenuView *view;

@end
