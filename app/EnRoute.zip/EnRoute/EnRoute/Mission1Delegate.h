//
//  Mission1Delegate.h
//  EnRoute
//
//  Created by Thomas Verleye on 9/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Mission1Delegate <NSObject>
@required
-(void) Mission1Finished;
@end
