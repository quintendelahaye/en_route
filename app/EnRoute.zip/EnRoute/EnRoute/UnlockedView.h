//
//  UnlockedView.h
//  EnRoute
//
//  Created by Thomas Verleye on 9/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnlockedView : UIView

@end
