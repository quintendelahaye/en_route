//
//  LoginViewController.h
//  EnRoute
//
//  Created by Quinten Delahaye on 01/06/14.
//  Copyright (c) 2014 Quinten Delahaye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginView.h"
#import <AFNetworking.h>
#import "StartScreenViewController.h"
@interface LoginViewController : UIViewController

@property (strong,nonatomic)LoginView *view;

@end
